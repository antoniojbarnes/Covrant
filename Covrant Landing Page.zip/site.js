// Closes the Products dropdown on outside click, link click, or Escape.
(function () {
  var dd = document.querySelector('.dd');
  if (!dd) return;
  document.addEventListener('click', function (e) {
    if (!dd.contains(e.target) || e.target.closest('.dd-menu a')) dd.removeAttribute('open');
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') dd.removeAttribute('open');
  });
})();
