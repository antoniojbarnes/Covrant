// Covrant — Return Intake PWA
// Service worker: app-shell precache + offline-first navigation.
// No backend exists in this build — the "sync" step is simulated client-side
// in app.js. The service worker's job is purely to make the app itself
// installable and available with zero connectivity.

const CACHE_VERSION = 'covrant-intake-v1';
const APP_SHELL = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.webmanifest',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_VERSION)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

// Cache-first for the app shell. Everything this app needs is precached,
// so a cold offline load still renders the full intake form.
self.addEventListener('fetch', (event) => {
  const req = event.request;

  // Only handle GET requests for same-origin app-shell assets.
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) {
    return;
  }

  event.respondWith(
    caches.match(req).then((cached) => {
      if (cached) return cached;
      return fetch(req)
        .then((res) => {
          // Opportunistically cache anything new same-origin GET requests pull in.
          const resClone = res.clone();
          caches.open(CACHE_VERSION).then((cache) => cache.put(req, resClone));
          return res;
        })
        .catch(() => {
          // Navigations that miss cache and have no network fall back to the shell.
          if (req.mode === 'navigate') {
            return caches.match('./index.html');
          }
        });
    })
  );
});

// Background Sync support (Chrome/Edge/Android). iOS Safari doesn't support
// this API, so app.js also drains the queue on the 'online' event as the
// universal fallback — this handler is a same-origin enhancement, not the
// only path to sync.
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-returns') {
    event.waitUntil(
      self.clients.matchAll().then((clients) => {
        clients.forEach((client) => client.postMessage({ type: 'SYNC_REQUESTED' }));
      })
    );
  }
});
