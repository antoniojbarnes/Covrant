/* ============================================================
   Covrant — Return Intake PWA
   Offline-first: every submission writes to IndexedDB first,
   then attempts to sync. No real backend exists in this build —
   syncRecord() simulates a network POST with a delay so the
   offline → reconnect → sync flow is demonstrable end-to-end.
   ============================================================ */

const DB_NAME = 'covrant-intake';
const DB_VERSION = 1;
const STORE = 'returns';

let db = null;
let forceOffline = false;
let formStartedAt = null;
let deferredInstallPrompt = null;

// ---------- IndexedDB wrapper ----------
function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const database = req.result;
      if (!database.objectStoreNames.contains(STORE)) {
        const store = database.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('syncStatus', 'syncStatus', { unique: false });
        store.createIndex('createdAt', 'createdAt', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function tx(storeName, mode) {
  return db.transaction(storeName, mode).objectStore(storeName);
}

function dbAdd(record) {
  return new Promise((resolve, reject) => {
    const req = tx(STORE, 'readwrite').add(record);
    req.onsuccess = () => resolve(record);
    req.onerror = () => reject(req.error);
  });
}

function dbPut(record) {
  return new Promise((resolve, reject) => {
    const req = tx(STORE, 'readwrite').put(record);
    req.onsuccess = () => resolve(record);
    req.onerror = () => reject(req.error);
  });
}

function dbGetAll() {
  return new Promise((resolve, reject) => {
    const req = tx(STORE, 'readonly').getAll();
    req.onsuccess = () => resolve(req.result.sort((a, b) => b.createdAt - a.createdAt));
    req.onerror = () => reject(req.error);
  });
}

// ---------- Photo capture + client-side compression ----------
// Target: < 1MB per photo, no visible quality loss (PRD F-01 acceptance criteria).
async function compressImage(file, maxDim = 1600, targetBytes = 1024 * 1024) {
  const bitmap = await createImageBitmap(file);
  let { width, height } = bitmap;

  if (width > maxDim || height > maxDim) {
    const scale = maxDim / Math.max(width, height);
    width = Math.round(width * scale);
    height = Math.round(height * scale);
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(bitmap, 0, 0, width, height);

  let quality = 0.9;
  let blob = await canvasToBlob(canvas, quality);

  while (blob.size > targetBytes && quality > 0.4) {
    quality -= 0.1;
    blob = await canvasToBlob(canvas, quality);
  }

  const dataUrl = canvas.toDataURL('image/jpeg', quality);
  return { blob, dataUrl, sizeBytes: blob.size, width, height };
}

function canvasToBlob(canvas, quality) {
  return new Promise((resolve) => {
    canvas.toBlob((blob) => resolve(blob), 'image/jpeg', quality);
  });
}

function fmtBytes(n) {
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(0) + ' KB';
  return (n / (1024 * 1024)).toFixed(2) + ' MB';
}

function uid() {
  return 'RTN-' + Date.now().toString(36).toUpperCase() + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
}

// ---------- App state ----------
const photoSlots = {
  item: { caption: 'Item', file: null },
  label: { caption: 'Label', file: null },
  damage: { caption: 'Damage', file: null },
  package: { caption: 'Package', file: null },
};
let selectedGrade = null;

// ---------- DOM refs ----------
const els = {};

function bindEls() {
  [
    'statusDot','statusText','pendingChip','pendingChipText',
    'installBtn','offlineBanner','submitBtn','submitHint',
    'vendorSelect','skuInput','serialInput','dateInput','reasonSelect','notesInput',
    'gradeGrid','queueList','queueEmpty','toast','toastMsg','toastIcon',
    'demoSwitch','timerChip','timerText','photoHint',
  ].forEach((id) => (els[id] = document.getElementById(id)));
}

// ---------- Toast ----------
let toastTimer;
function showToast(msg, icon = '✓') {
  els.toastMsg.textContent = msg;
  els.toastIcon.textContent = icon;
  els.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.remove('show'), 2800);
}

// ---------- Connectivity ----------
function isOnline() {
  return !forceOffline && navigator.onLine;
}

function updateConnectivityUI() {
  const online = isOnline();
  els.statusDot.className = 'status-dot ' + (online ? 'online' : 'offline');
  els.statusText.className = 'status-text ' + (online ? 'online-text' : 'offline-text');
  els.statusText.textContent = online ? 'Online' : 'Offline — queuing locally';
  els.offlineBanner.classList.toggle('show', !online);
}

// ---------- Photo slot rendering ----------
function renderPhotoSlot(key) {
  const slot = document.querySelector(`[data-slot="${key}"]`);
  const data = photoSlots[key];
  const existingImg = slot.querySelector('img');
  const existingCheck = slot.querySelector('.photo-slot-check');
  const existingCap = slot.querySelector('.photo-slot-caption');
  if (existingImg) existingImg.remove();
  if (existingCheck) existingCheck.remove();
  if (existingCap) existingCap.remove();

  if (data.file) {
    slot.classList.add('filled');
    const img = document.createElement('img');
    img.src = data.file.dataUrl;
    slot.appendChild(img);
    const check = document.createElement('div');
    check.className = 'photo-slot-check';
    check.textContent = '✓';
    slot.appendChild(check);
    const cap = document.createElement('div');
    cap.className = 'photo-slot-caption';
    cap.textContent = fmtBytes(data.file.sizeBytes);
    slot.appendChild(cap);
  } else {
    slot.classList.remove('filled');
  }
  updateSubmitState();
}

async function handlePhotoInput(key, fileInput) {
  const file = fileInput.files && fileInput.files[0];
  if (!file) return;
  markFormStarted();

  const slot = document.querySelector(`[data-slot="${key}"]`);
  const icon = slot.querySelector('.photo-slot-icon');
  const label = slot.querySelector('.photo-slot-label');
  const originalIcon = icon.textContent;
  icon.textContent = '⏳';
  label.textContent = 'Compressing…';

  try {
    const compressed = await compressImage(file);
    photoSlots[key].file = {
      blob: compressed.blob,
      dataUrl: compressed.dataUrl,
      sizeBytes: compressed.sizeBytes,
      mediaType: 'photo',
      caption: photoSlots[key].caption,
    };
    renderPhotoSlot(key);
  } catch (e) {
    console.error('Photo compression failed', e);
    showToast('Could not process photo — try again', '⚠️');
  } finally {
    icon.textContent = originalIcon;
    label.textContent = photoSlots[key].caption;
    fileInput.value = '';
  }
}

function photoCount() {
  return Object.values(photoSlots).filter((s) => s.file).length;
}

// ---------- Grade selection ----------
function selectGrade(el, grade) {
  document.querySelectorAll('.grade-btn').forEach((b) => b.classList.remove('selected'));
  el.classList.add('selected');
  selectedGrade = grade;
  markFormStarted();
  updateSubmitState();
}

// ---------- Form timer ----------
function markFormStarted() {
  if (!formStartedAt) {
    formStartedAt = Date.now();
    tickTimer();
  }
}

let timerInterval;
function tickTimer() {
  els.timerChip.style.display = 'inline-flex';
  timerInterval = setInterval(() => {
    const elapsed = Math.floor((Date.now() - formStartedAt) / 1000);
    const m = Math.floor(elapsed / 60);
    const s = elapsed % 60;
    els.timerText.textContent = m + ':' + String(s).padStart(2, '0');
  }, 1000);
}

function resetTimer() {
  clearInterval(timerInterval);
  formStartedAt = null;
  els.timerChip.style.display = 'none';
  els.timerText.textContent = '0:00';
}

// ---------- Submit gating ----------
function updateSubmitState() {
  const hasPhoto = photoCount() > 0;
  const hasIdentifier = els.skuInput.value.trim() || els.serialInput.value.trim();
  const hasGrade = !!selectedGrade;
  const ready = hasPhoto && hasIdentifier && hasGrade;
  els.submitBtn.disabled = !ready;

  const missing = [];
  if (!hasPhoto) missing.push('a photo');
  if (!hasIdentifier) missing.push('SKU or serial');
  if (!hasGrade) missing.push('condition grade');
  els.submitHint.textContent = ready
    ? 'Ready to log this return'
    : 'Add ' + missing.join(', ') + ' to continue';
}

// ---------- Submit ----------
async function handleSubmit() {
  const photos = Object.values(photoSlots)
    .filter((s) => s.file)
    .map((s) => ({
      caption: s.file.caption,
      mediaType: s.file.mediaType,
      blob: s.file.blob,
      sizeBytes: s.file.sizeBytes,
    }));

  const record = {
    id: uid(),
    vendor: els.vendorSelect.value,
    sku: els.skuInput.value.trim(),
    serial: els.serialInput.value.trim(),
    dateReceived: els.dateInput.value,
    reason: els.reasonSelect.value,
    notes: els.notesInput.value.trim(),
    grade: selectedGrade,
    photos,
    createdAt: Date.now(),
    syncStatus: 'pending',
    syncedAt: null,
  };

  await dbAdd(record);

  const elapsedLabel = formStartedAt
    ? ' in ' + Math.max(1, Math.floor((Date.now() - formStartedAt) / 1000)) + 's'
    : '';
  showToast('Return ' + record.id + ' logged' + elapsedLabel, '📋');

  resetForm();
  await refreshQueue();

  if (isOnline()) {
    syncPending();
  } else {
    tryRegisterBackgroundSync();
  }
}

function resetForm() {
  Object.keys(photoSlots).forEach((key) => {
    photoSlots[key].file = null;
    renderPhotoSlot(key);
  });
  document.querySelectorAll('.grade-btn').forEach((b) => b.classList.remove('selected'));
  selectedGrade = null;
  els.skuInput.value = '';
  els.serialInput.value = '';
  els.notesInput.value = '';
  els.dateInput.valueAsDate = new Date();
  resetTimer();
  updateSubmitState();
}

// ---------- Sync engine ----------
// No backend exists — this simulates a POST /returns call per pending record.
function simulateUpload(record) {
  return new Promise((resolve) => {
    const delay = 700 + Math.random() * 700;
    setTimeout(resolve, delay);
  });
}

let syncing = false;
async function syncPending() {
  if (syncing) return;
  const all = await dbGetAll();
  const pending = all.filter((r) => r.syncStatus === 'pending');
  if (pending.length === 0) return;

  syncing = true;
  updatePendingChip(pending.length, true);

  for (const record of pending) {
    record.syncStatus = 'syncing';
    await dbPut(record);
    await refreshQueue();

    await simulateUpload(record);

    record.syncStatus = 'synced';
    record.syncedAt = Date.now();
    await dbPut(record);
    await refreshQueue();
  }

  syncing = false;
  const remaining = (await dbGetAll()).filter((r) => r.syncStatus === 'pending').length;
  updatePendingChip(remaining, false);

  if (pending.length > 0) {
    showToast(pending.length + ' return' + (pending.length > 1 ? 's' : '') + ' synced', '☁️');
  }
}

function updatePendingChip(count, isSyncing) {
  if (count === 0 && !isSyncing) {
    els.pendingChip.classList.add('hidden');
    return;
  }
  els.pendingChip.classList.remove('hidden');
  els.pendingChip.classList.toggle('syncing', isSyncing);
  els.pendingChipText.textContent = isSyncing
    ? 'Syncing ' + count + '…'
    : count + ' pending sync';
}

async function tryRegisterBackgroundSync() {
  if (!('serviceWorker' in navigator)) return;
  try {
    const reg = await navigator.serviceWorker.ready;
    if ('sync' in reg) {
      await reg.sync.register('sync-returns');
    }
  } catch (e) {
    // Background Sync unsupported (e.g. iOS Safari) — the 'online' event
    // listener below is the universal fallback and covers this case.
  }
}

// ---------- Queue list rendering ----------
async function refreshQueue() {
  const all = await dbGetAll();
  const pendingCount = all.filter((r) => r.syncStatus !== 'synced').length;
  updatePendingChip(pendingCount, syncing);

  if (all.length === 0) {
    els.queueEmpty.style.display = 'block';
    els.queueList.innerHTML = '';
    els.queueList.appendChild(els.queueEmpty);
    return;
  }

  els.queueList.innerHTML = '';
  all.slice(0, 25).forEach((r) => {
    const row = document.createElement('div');
    row.className = 'queue-row';

    const thumb = document.createElement('div');
    thumb.className = 'queue-thumb';
    if (r.photos && r.photos[0] && r.photos[0].blob) {
      const img = document.createElement('img');
      img.src = URL.createObjectURL(r.photos[0].blob);
      thumb.appendChild(img);
    } else {
      thumb.textContent = '📦';
    }

    const info = document.createElement('div');
    info.className = 'queue-info';
    const title = document.createElement('div');
    title.className = 'queue-title';
    title.textContent = r.id;
    const meta = document.createElement('div');
    meta.className = 'queue-meta';
    meta.textContent = [capitalize(r.vendor), 'Grade ' + (r.grade || '—'), r.photos.length + ' photo' + (r.photos.length === 1 ? '' : 's')].join(' · ');
    info.appendChild(title);
    info.appendChild(meta);

    const status = document.createElement('div');
    status.className = 'queue-status ' + r.syncStatus;
    status.textContent = r.syncStatus === 'pending' ? 'Pending' : r.syncStatus === 'syncing' ? 'Syncing…' : 'Synced';

    row.appendChild(thumb);
    row.appendChild(info);
    row.appendChild(status);
    els.queueList.appendChild(row);
  });
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

// ---------- Install prompt ----------
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  els.installBtn.classList.add('show');
});

window.addEventListener('appinstalled', () => {
  els.installBtn.classList.remove('show');
  deferredInstallPrompt = null;
  showToast('Covrant Intake installed', '🎉');
});

async function handleInstallClick() {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt = null;
  els.installBtn.classList.remove('show');
}

// ---------- Demo offline toggle (dev/demo affordance) ----------
// Real device offline testing (airplane mode) works normally via the
// online/offline events below. This switch exists purely so the offline
// → queue → reconnect → sync flow can be demonstrated without leaving
// the browser tab.
function toggleDemoOffline() {
  forceOffline = !forceOffline;
  els.demoSwitch.classList.toggle('on', forceOffline);
  updateConnectivityUI();
  if (!forceOffline && navigator.onLine) {
    syncPending();
  }
}

// ---------- Connectivity events ----------
window.addEventListener('online', () => {
  updateConnectivityUI();
  if (!forceOffline) syncPending();
});
window.addEventListener('offline', updateConnectivityUI);

// ---------- Service worker message channel ----------
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.addEventListener('message', (event) => {
    if (event.data && event.data.type === 'SYNC_REQUESTED' && isOnline()) {
      syncPending();
    }
  });
}

// ---------- Init ----------
async function init() {
  bindEls();
  db = await openDB();

  els.dateInput.valueAsDate = new Date();
  updateConnectivityUI();
  await refreshQueue();

  if (isOnline()) syncPending();

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('./sw.js').catch((e) => {
      console.warn('Service worker registration failed (expected on file:// or non-secure origins):', e.message);
    });
  }
}

document.addEventListener('DOMContentLoaded', init);
